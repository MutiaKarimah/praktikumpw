<?php 
 header("location:/");
?>